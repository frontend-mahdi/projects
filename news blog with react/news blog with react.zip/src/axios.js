import axios from "axios";

const instance = axios.create({
  baseURL:
    "https://news-blog-41f7b-default-rtdb.europe-west1.firebasedatabase.app",
});

export default instance;
