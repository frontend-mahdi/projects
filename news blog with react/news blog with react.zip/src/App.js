import React from "react";
import { Switch, Route, withRouter } from "react-router-dom";
import Context from "./context/posts-ctx";
import axios from "./axios";
import "./App.css";
import PageTitle from "./components/pageTitle/PageTitle";
import About from "./components/about/About";
import Form from "./containers/form/Form";
import Posts from "./containers/posts/Posts";
import FullPost from "./components/fullpost/FullPost";
import MainLayout from "./components/layout/MainLayout";

class App extends React.Component {
  state = {
    posts: [],
    showBackdrop: false,
  };
  constructor(props) {
    super(props);
    this.handlePostLikes = this.handlePostLikes.bind(this);
    this.updatePosts = this.updatePosts.bind(this);
    this.handlePostDelete = this.handlePostDelete.bind(this);
  }
  componentDidMount() {
    this.updatePosts();
  }
  updatePosts() {
    this.setState({ showBackdrop: true });
    axios.get("/posts.json").then((response) => {
      const fetchedPosts = [];
      for (const key in response.data) {
        fetchedPosts.push({
          ...response.data[key],
          fireBaseKey: key,
        });
      }
      this.setState({ posts: fetchedPosts });
      this.setState({ showBackdrop: false });
    });
  }

  handlePostLikes(id) {
    const posts = [...this.state.posts];
    const post = posts.find((item) => item.id === id);
    post.likes++;
    axios.put(`/posts/${post.fireBaseKey}/likes.json`, post.likes);
  }
  handlePostDelete(id) {
    this.setState({ showBackdrop: true });

    const posts = [...this.state.posts];
    const post = posts.find((item) => item.id === id);
    axios.delete(`/posts/${post.fireBaseKey}.json`).then((response) => {
      this.props.history.push("/");
      this.setState({ showBackdrop: false });
    });
  }
  render() {
    return (
      <>
        <MainLayout>
          <Context.Provider
            value={{
              state: this.state,
              updatePosts: this.updatePosts,
              handlePostLikes: this.handlePostLikes,
              handlePostDelete: this.handlePostDelete,
            }}
          >
            <Switch>
              <Route exact path="/posts/:id">
                <FullPost />
              </Route>

              <Route exact path="/about">
                <About />
              </Route>

              <Route exact path="/newpost">
                <Form />
              </Route>

              <Route exact path="/">
                <Posts />
              </Route>
              <Route>
                <PageTitle title="Page Not Found!" />
              </Route>
            </Switch>
          </Context.Provider>
        </MainLayout>
      </>
    );
  }
}

export default withRouter(App);
