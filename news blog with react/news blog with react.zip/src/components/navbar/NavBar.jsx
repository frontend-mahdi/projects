import React from 'react'

import "./nav.css"
import NavItem from './NavItem'
import NavItems from './NavItems'

const NavBar = () => {

    return ( 
        <nav className="nav-bar">
            <NavItems>
                <NavItem title="Posts"/>
                <NavItem title="New post"/>
                <NavItem title="About me"/>
            </NavItems>
        </nav>
     );
}
 
export default NavBar;