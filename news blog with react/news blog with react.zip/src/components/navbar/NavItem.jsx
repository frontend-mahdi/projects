import React from 'react'

import {Link,withRouter} from 'react-router-dom'

import './nav.css'

const NavItem = (props) => {

    const url = props.location.pathname;
    let pageTitle ="";
    if(props.title === "Posts")  pageTitle = "/"
    else if(props.title === "New post")  pageTitle = "/newpost"
    else if(props.title === "About me")  pageTitle = "/about"
 
    const pageURL = url.toString()
    
  
    
    return ( 
        <li className={`nav-item ${pageURL === pageTitle ? "nav-item--active" :null}`}>
            <Link 
            className="nav-item-link" 
            to={pageTitle} 
            replace
            >
                    {props.title}
            </Link>


        </li>
     );
}
 
export default withRouter(NavItem);

