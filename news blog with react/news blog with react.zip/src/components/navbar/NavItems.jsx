import React from 'react'

import "./nav.css"

const NavItems = ({children}) => {
    return ( 
        <ul className="nav-items">
            {children}
        </ul>
     );
}
 
export default NavItems;