import React from 'react'
import {Link} from 'react-router-dom'

import {FaHeart} from 'react-icons/fa'


import "./card.css"

const Card = ({id,title,content,likes,date}) => {
    return ( 

        <Link to={`posts/${id}`}>
        
        
        <div className="card">

            <h3 className="card-title">{title}</h3>

            <p className="card-content">{content}</p>

            <section className="card-info">
               
                   
           
                <div className="card-info_date">{date}</div>

                <div className="card-info_likes">
                    <FaHeart color="red"/>{likes}
                </div>
            
            </section>
        </div>
        </Link>
     );
}
 
export default Card;