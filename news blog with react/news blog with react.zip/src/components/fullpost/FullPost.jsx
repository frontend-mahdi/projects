import React from 'react';
import Context from './../../context/posts-ctx'
import { useParams } from 'react-router-dom'

import Backdrop from './../backdrop/Backdrop'
import Description from './../../components/descriptions/Description'
import PageTitle from './../pageTitle/PageTitle';


const FullPost = () => {
    const {id} = useParams();
    return ( 
        <Context.Consumer>

            {
                ctx => {
                    const post = ctx.state.posts.find(item => item.id === id)
              

                    return (

                        <>
                            
                            <div>
                                {post ? (
                                    <>

                                <Backdrop show={ctx.state.showBackdrop}/>

                                <PageTitle title={post.title}/>
                                
                                <Description 
                                    content={post.content}
                                    author={post.author}
                                    date={post.date}
                                    like={()=>ctx.handlePostLikes(post.id)}
                                    Delete={()=>ctx.handlePostDelete(post.id)}
                                />
                                </>) : <PageTitle title="No Post Available!"/> }
                                
                        
                            </div>
                        </>
                    )
                }
            }

        </Context.Consumer>
       
     );
}
 
export default FullPost;