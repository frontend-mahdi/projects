import React from 'react';

import {ImSpinner10} from 'react-icons/im';
import './backdrop.css'

const Backdrop = ({show}) => {
    return show ? (
    <div className="backdrop">
        <ImSpinner10 className="backdrop-spinner"/>
    </div>) : null  
}
 
export default Backdrop;