import React from 'react'

import PageTitle from '../pageTitle/PageTitle';
import "./about.css"

const About = () => {
    return ( 
        <>
            <PageTitle title="About me"/>
                                
            <div style={{textAlign:"center"}}>
                               
                <div className="about-box">
                        
                    <section className="about-text">
                            
                        <p>This is a simple React js project built for training seasons like: context api, lifecycles, react-router ,api and firebase</p>

                        <p>Developed by : Mohammad Mahdi Abolghasemi (frontend developer)</p>
                    
                        <p>Contact me: mahdi.313.ab@gmail.com</p>
                        <p><mark>!PLEASE TRUN ON YOUR VPN!</mark></p>

                     </section>
            
                </div>
            </div>
        </>
     );
}
 
export default About;