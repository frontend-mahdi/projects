import React,{useState} from 'react'

import {withRouter} from 'react-router-dom'

import {FaRegHeart , FaHeart} from 'react-icons/fa'
import Btn from '../btns/Btn'

import "./description.css"

const Description = (props) => {

    const [likeStatus,setLikeStatus]=useState(false)
    const likePostHandler = ()=>{
        // prevent user to like post more than one time!
        if(!props.location.state){

            props.location.state = true
            setLikeStatus(true);
            props.like();
        }
    }
    return ( 
        <div style={{textAlign:"center"}}>

        <div className="description-box">
            <p className="description-text">{props.content}</p>
            <section className="description-info">
               
                <div className="description-info-author">Author: {props.author}</div>
                   
               <div className="description-info_like">
                   <span>Enjoy it?</span>
                   <div 
                   style={{display:"inline-block"}} 
                   onClick={likePostHandler}>
                        {!likeStatus ? 
                        <FaRegHeart 
                            className="description-info_heart" 
                            color="#fd3c4a"/> 
                   : <FaHeart 
                   className="description-info_heart" 
                   color="#fd3c4a"/>
                   }
                   </div>
                   
                   
                   
               </div>
               <div className="description-info_date">{props.date}</div>

           
           </section>
        </div>
        <Btn title="Delete Post" size="sm" color="danger" onClick={props.Delete}/>
        {/* <Btn title="Add New Post" size="lg" color="success"/> */}
        </div>
     );
}
 
export default withRouter(Description);