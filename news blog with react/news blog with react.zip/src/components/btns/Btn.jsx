import React from 'react'

import {FaRegTrashAlt , FaRegPlusSquare} from 'react-icons/fa'

const Btn = ({title,size,color,onClick}) => {

    const btnStyle = {

        textSize: size === "sm" ? ".875rem"
        : size === "lg" ? "1.125rem"
        : null,

        padding: size === "sm" ? ".785em 1.5em" 
        : size === "lg" ? ".95em 4.95em" 
        : null ,

        color: color === "danger" ? "#fd3c4a" 
        : color === "success" ? "#fcfcfc" 
        : null ,
        
        backgroundColor: color === "danger" ? "#eee5ff" 
        : color === "success" ? "#00a86b" 
        : null ,

        display:"inline-block",
        textAlign:"center",
        margin:"2rem auto",
        borderRadius:"1rem",
        cursor:"pointer",
        fontWeight:"600"
     
    }
    const iconStyle = {
        paddingRight:"2px"
    }

    return <div style={btnStyle} onClick={onClick}>
        {title === "Delete Post" ? <FaRegTrashAlt style={iconStyle}/> : title === "Add New Post" ? <FaRegPlusSquare style={iconStyle}/> : null}
        {title}
        </div>
}

export default Btn