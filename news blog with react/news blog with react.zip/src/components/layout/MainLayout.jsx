import React from 'react'
// import { useParams, useRouteMatch } from 'react-router-dom'

import NavBar from './../navbar/NavBar'


const MainLayout = ({children }) => {
  
    // const {url} = useRouteMatch();
    // const {id} =useParams();

    return ( 
        
        <>
            <NavBar />
            <div  style={{ padding: "0 calc(40px + 1.375rem)" }}> 
                {children}
            </div>
        </>
        
     );
}
 
export default MainLayout;