import React from "react";

const Context = React.createContext({
  state: {},
  updatePosts: () => {},
  handlePostLikes: () => {},
});

export default Context;
