import React,{useEffect,useContext} from 'react'

import Context from './../../context/posts-ctx'
import Backdrop from '../../components/backdrop/Backdrop';


import PageTitle from '../../components/pageTitle/PageTitle';
import Card from "./../../components/card/Card";

const Posts = () => {
    const ctx = useContext(Context);

    useEffect(() => {
        ctx.updatePosts();
        // prevent warning in console
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])

    return ( 
        <>
        <Backdrop show={ctx.state.showBackdrop}/>
        <div>
            {ctx.state.posts.length > 0 ? <PageTitle title="Posts"/> : <PageTitle title="No Post Available!"/>}
        

        <div 
            style={{display:"flex" ,justifyContent:"flex-start",flexWrap:"wrap"}}
        >

        {ctx.state.posts.map(item => 
            
            <Card 
                key={item.id}
                id={item.id}
                title={item.title}
                content={item.content}
                likes={item.likes}
                date={item.date}
            />
        )}
            
        </div>
        </div>

    </>
     );
}
 
export default Posts;
