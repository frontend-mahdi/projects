import React,{useState} from 'react';
import {withRouter} from 'react-router-dom'

import {v4} from 'uuid';
import date from 'date-and-time'

import Backdrop from '../../components/backdrop/Backdrop';
import axios from './../../axios';
import Btn from './../../components/btns/Btn'
import PageTitle from '../../components/pageTitle/PageTitle';

import './form.css';

const Form = (props) => {
    const [newTitle,setNewTitle] = useState("");
    const [newContent,setNewContent] = useState("");
    const [newAuthor,setNewAuthor]= useState("");



    const [showBackdrop,setShowBackdrop]=useState(false);
    const submit = () =>{
        setShowBackdrop(true);

        const now = new Date();
        
        const newCard = {
            id:v4(),
            title:newTitle,
            content:newContent,
            author:newAuthor,
            likes:0,
            date: date.format(now,'MMM DD,YYYY[ | ]hh:mm A')
            
        }
        axios.post('/posts.json',newCard).then(response => {
            setNewTitle("")
            setNewContent("")
            setNewAuthor("");
        }).then(response => {
            setShowBackdrop(false);
            props.history.push("/");
        })
    }
    return ( 
        <div style={{textAlign:"center"}}>
            <Backdrop show={showBackdrop}/>
            <div>
                <PageTitle title="Add New Post"/> 
                <div className="form-box">
                    <form>  
                        <input 
                            value={newTitle} 
                            onChange={event => setNewTitle(event.target.value)}
                            type="text" 
                            className="form-input" 
                            placeholder="Title..."
                            required 
                        />
                        
                        <textarea 
                            value={newContent}
                            onChange={event => setNewContent(event.target.value)}
                            type="text" 
                            className="form-input" placeholder="content" 
                            rows="5" 
                            cols="100"
                            required 
                        />
                            
                        <input 
                            value={newAuthor}
                            onChange={event => setNewAuthor(event.target.value)}
                            type="text" 
                            className="form-input" 
                            placeholder="author"
                            required 
                        />

                        <Btn 
                            onClick={submit}
                            title="Add New Post" 
                            size="lg" 
                            color="success"
                        />
                
                </form>
            </div>
        </div>

        

        </div>
     );
}
 
export default withRouter(Form);